<?php
	die( 'You may no longer trigger this cron directly. Trigger the pmpro_cron_trial_ending_warnings hook via WP-Cron.' );
