<?php
	die( 'You may no longer trigger this cron directly. Trigger the pmpro_cron_credit_card_expiring_warnings hook via WP-Cron.' );
