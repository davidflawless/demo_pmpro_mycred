<?php
	die( 'You may no longer trigger this cron directly. Trigger the pmpro_cron_expire_memberships hook via WP-Cron.' );
