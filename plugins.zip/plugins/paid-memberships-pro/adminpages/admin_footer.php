<div class="clear"></div>
</div> <!-- end .pmpro_admin -->
