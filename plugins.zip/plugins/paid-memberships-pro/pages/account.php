<?php
/**
 * Template: Account
 * Version: 2.0
 *
 * See documentation for how to override the PMPro templates.
 * @link https://www.paidmembershipspro.com/documentation/templates/
 *
 * @version 2.0
 *
 * @author Paid Memberships Pro
 */
// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
echo pmpro_shortcode_account('');
